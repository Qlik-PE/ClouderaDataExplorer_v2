define( [
	"jquery",
  "./xltr",
  "./appbuilder",
  "text!./odi.html",
  "text!./odi.css"
],
function ($, Translator, AppBuilderFactory, odiHtml, odiCss) {
  'use strict';

  // inject style
  $("<style>").html('<style type="text/css">' + odiCss + "</style>").appendTo("head");

  var translator = Translator;


  function GetGenAppBtnLabel(scp, layout) {
    if(layout.genAppBtnLbl) {
      scp.genAppBtnLbl = layout.genAppBtnLbl;
    } else if(layout.genAppName && layout.genAppName.length > 0) {
      scp.genAppBtnLbl = translator.get("odi.genAppBtnLbl", [layout.genAppName]);
    } else if(scp.targetApp && scp.targetApp.length > 0) {
      scp.genAppBtnLbl = translator.get("odi.genAppBtnLbl", [scp.targetApp]);
    } else {
      scp.genAppBtnLbl = translator.get("odi.genAppBtnLblUnknown");
    }
  }

  function doInitialApply(scp) {
    if (scp.firstTime) {
      scp.firstTime = 0;
      scp.$apply();
    }
  }

  return {
    template: odiHtml,

    initialProperties: {
      version: 1.0,
      qHyperCubeDef: {
        qDimensions: [],
        qMeasures: [],
        qInitialDataFetch: [{
          qWidth: 1,
          qHeight: 1
        }]
      }
    },
    definition: {
      type: "items",
      component: "accordion",
      items: {
        measures: {
          uses: "measures",
          min: 0,
          max: 1
        },
        advanced:{
          label: Translator.get("odi.advancedCategoryLabel"),
          type: "items",
          items:{
            genAppName: {
              ref: "genAppName",
              translation: Translator.get("odi.genAppNamePropLabel"),
              type: "string",
              defaultValue: ""
            },
            maxGenerated : {
              ref: "maxGenerated",
              translation: Translator.get("odi.maxGenAppsPropLabel"),
              type: "integer",
              defaultValue: 1
            },
            genAppBtnLbl : {
              ref: "genAppBtnLbl",
              translation: Translator.get("odi.genAppBtnPropLabel"),
              type: "string"
            },
            openAppBtnLbl : {
              ref: "openAppBtnLbl",
              translation: Translator.get("odi.openAppBtnPropLabel"),
              type: "string"
            },
            showLog: {
              ref: "showLog",
              translation: Translator.get("odi.showLogPropLabel"),
              defaultValue: "false",
              type: "boolean"
            },
            quoteCharacter: {
              ref: "advanced.quoteCharacter",
              translation: Translator.get("odi.quoteCharPropLabel"),
              type: "string",
              defaultValue: "'",
              maxlength : 4
            },
            delimiter: {
              ref: "advanced.delimiter",
              translation: Translator.get("odi.valueSeparatorPropLabel"),
              type: "string",
              defaultValue: ",",
              maxlength: 4
            }
          }
        },
        targetApp: {
          ref: "targetApp",
          // label: "On-Demand App",
          label : Translator.get("odi.onDemandAppCategoryLabel"),
          items: {
            templateApp: {
              ref: "targetApp",
              translation: Translator.get("odi.targetAppPropLabel"),
              type: "string",
              defaultValue: ""
            },
            targetAppSheet: {
              ref: "targetAppSheet",
              translation: Translator.get("odi.initialSheetPropLabel"),
              type: "string",
              defaultValue: ""
            },
            openAppMethod : {
              ref: "openAppMethod",
              translation: Translator.get("odi.openAppMethodPropLabel"),
              component: "dropdown",
              options: [
                {value: "tab", label: Translator.get("odi.newTabMethodOptLabel")},
                {value: "win", label: Translator.get("odi.newWindowMethodOptLabel")},
				{value: "frame", label: Translator.get("odi.newframeMethodOptLabel")}
              ],
              defaultValue: "tab"
            }
          }
        }
      }
    },
    controller: function($scope, $window) {  //eslint-disable-line no-unused-vars
      $scope.appBuilder = AppBuilderFactory.createAppBuilder();
      $scope.firstTime = 1;

      $scope.exprNotSet = false;
      $scope.recLimitNotSet = false;
      $scope.appNameNotSet = false;
      $scope.noBindings = false;
      $scope.invTemplAppName = false;
      $scope.templateAppNotFound = '';
      $scope.checkBindError = false;
      $scope.error = null;
      $scope.rowCount = null;
      $scope.rowsAvailable = '';
      $scope.view = '';
      $scope.progress = "";
      $scope.lastError = null;
      $scope.progmsgs = null;
      $scope.isDesktop = false;

      $scope.errorCount = null;
      $scope.limit = 0;
      $scope.filterMoreMsg = '';

      $scope.newAppUrl = null;
      $scope.targetApp = null;
      $scope.targetAppSheet = null;
      $scope.maxGenerated = 1;

      $scope.matchExpr = "";
      $scope.genAppName = null;
      $scope.cancelPending = false;
      $scope.qtyConstrViolations = [];

      $scope.genAppBtnLbl = translator.get("odi.genAppBtnLblUnknown");
      $scope.openAppBtnLbl = null;

      // translations for HTML
      $scope.odiChangesNeeded = Translator.get("odi.changesNeeded");
      $scope.odiRecordCountExpMissing = Translator.get("odi.recordCountExpMissing");
      $scope.odiRecordLimitValueMissing = Translator.get("odi.recordLimitValueMissing");
      $scope.odiTemplAppNameMissing = Translator.get("odi.oddTemplAppNameMissing");
      $scope.odiNoMatchingBindExp = Translator.get("odi.noMatchingBindExp");
      $scope.odiCancelReload = Translator.get("odi.cancelReload");
      $scope.odiReloadErrorHeader = Translator.get("odi.reloadErrorHeader");
      $scope.odiAcknowledgeErrorButton = Translator.get("odi.acknowledgeErrorButton");
      $scope.maxGeneratedTooLow = Translator.get("odi.maxGeneratedTooLow");
      $scope.desktopNotSupported = Translator.get("odi.desktopNotSupported");

      $scope.$parent.component.measureDefinition.items.limit = {
        type: "number",
        label: Translator.get("odi.recordLimitPropLabel"),
        ref: "qDef.limit",
        show: true
      };

      // ************   Main Angular bind functions *************

      $scope.createApp = function() {
        $scope.view = "processing";
        $scope.cancelPending = false;
        $scope.progmsgs = [];
        $scope.errorCount = 0;
        // initialize state that AppBuilder will require
        $scope.appBuilder.Init($scope, this.$parent.layout, translator);
        $scope.appBuilder.CreateApp();
      };

      // Angular Bind Entry Point: openNewApp
	  
	  //Customized Code for QDC
      $scope.openNewApp = function () {
        //window.location = $scope.newAppUrl;
        $scope.view = "ready";
        if($scope.openAppMethod === 'win') {
          window.open($scope.newAppUrl, 'newwindow','width=' + window.innerWidth + ', ' + 'height=' + window.innerHeight);
          return false;
        }
		if($scope.openAppMethod === 'frame') {
		    var iframe = document.createElement('iframe');
   			iframe.style.width = 100+"%";
        	iframe.style.height = 99+"%";
        	iframe.frameBorder = 0;
    		iframe.src = $scope.newAppUrl;
    		document.body.appendChild(iframe);
			return false;
		}
		window.open($scope.newAppUrl);
	  };

//	  //Original Code
//	  $scope.openNewApp = function () {
//        //window.location = $scope.newAppUrl;
//        $scope.view = "ready";
//        if($scope.openAppMethod === 'win') {
//          window.open($scope.newAppUrl, 'newwindow','width=' + window.innerWidth + ', ' + 'height=' + window.innerHeight);
//          return false;
//        }
//        window.open($scope.newAppUrl);
//      };
	  

      $scope.acknowledgeError = function () {
        $scope.view = "ready";
      };

      $scope.cancelReload = function() {
        $scope.appBuilder.Init($scope, this.$parent.layout, translator);
        $scope.appBuilder.CancelReload();
      };

      $scope.showLogChanged = function() {
        this.$parent.layout.showLog = $scope.showLog;
      };

    }, // end controller

    // *****       Main paint method

    paint: function ($element, layout) {
      var targetAppNameChanged = false;
      var scp = this.$scope;

      scp.qtyConstrViolations = [];

      //first we check to see if the row conditions have been met
      // console.log(layout);
      scp.openAppMethod = layout.openAppMethod;

      if(layout.targetApp !== scp.targetApp) {
        targetAppNameChanged = true;
      }
      scp.targetApp = layout.targetApp;

      if(typeof layout.maxGenerated === 'undefined') {
        scp.maxGenerated = 1;
      } else {
        scp.maxGenerated = parseInt(layout.maxGenerated);
      }
      if(layout.targetAppSheet && layout.targetAppSheet.length > 0) {
        scp.targetAppSheet = layout.targetAppSheet;
      }
      scp.exprNotSet = true;
      scp.recLimitNotSet = true;
      scp.appNameNotSet = true;
      if(layout.qHyperCube && layout.qHyperCube.qDataPages && layout.qHyperCube.qDataPages.length > 0 &&
         layout.qHyperCube.qDataPages[0].qMatrix.length > 0 && !isNaN(layout.qHyperCube.qDataPages[0].qMatrix[0][0].qNum)) {
        scp.exprNotSet = false;
      }
      if (layout.qHyperCube && layout.qHyperCube.qMeasureInfo.length > 0 &&
         layout.qHyperCube.qMeasureInfo[0].limit && layout.qHyperCube.qMeasureInfo[0].limit > 0) {
          scp.recLimitNotSet = false;
          scp.limit = layout.qHyperCube.qMeasureInfo[0].limit;
      }
      if(scp.targetApp && scp.targetApp.length > 0) {
        scp.appNameNotSet = false;
      }

      if(layout.genAppName && layout.genAppName.length > 0) {
        scp.genAppName = layout.genAppName;
      } else {
        scp.genAppName = null;
      }

      scp.showLog = layout.showLog;

      if (layout.openAppBtnLbl) {
        scp.openAppBtnLbl = layout.openAppBtnLbl;
      }

      // only update the state if we're not currently handling a reload
      if(scp.view !== "processing") {
        // initialize state that AppBuilder will require
        scp.appBuilder.Init(scp, layout, translator);

        // verify that we have at least one binding
        scp.appBuilder.CheckBindings(targetAppNameChanged, function () {
          if(scp.isDesktop) {
            scp.view = "desktop";
            doInitialApply(scp);
          } else if (scp.exprNotSet || scp.appNameNotSet || scp.recLimitNotSet || scp.noBindings || scp.invTemplAppName ||
              scp.checkBindError || scp.maxGenerated < 1) {
            scp.view = "nocondition";
            if(scp.appNameNotSet) {
              scp.invTemplAppName = false;
            }
            if(scp.invTemplAppName  && !scp.appNameNotSet) {
              scp.templateAppNotFound = translator.get("odi.templateAppNotFound", [scp.targetApp]);
            }
            GetGenAppBtnLabel(scp, layout);
            doInitialApply(scp);
          } else {
            if (layout.qHyperCube.qDataPages[0]) {
              if (layout.qHyperCube.qDataPages[0].qMatrix[0]) {
                scp.rowCount = layout.qHyperCube.qDataPages[0].qMatrix[0][0].qNum;
                scp.rowsAvailable = translator.get("odi.rowsAvailable", [scp.rowCount]);
              }
            }
            if (scp.rowCount && scp.limit && scp.rowCount <= scp.limit) {
              // verify that all selection qty constraints are met and set the script by binding current selection state
              scp.appBuilder.CheckSelQtyConstraints()
                .then(function () {
                  if(scp.qtyConstrViolations.length === 0) {
                    scp.view = "ready";
                  } else {
                    scp.view = "qtyconstrviolations";
                  }
                  GetGenAppBtnLabel(scp, layout);
                  doInitialApply(scp);
              });
            } else {
              GetGenAppBtnLabel(scp, layout);
              scp.filterMoreMsg = translator.get("odi.filterMore", [scp.limit]);
              scp.view = "conditionnotmet";
              doInitialApply(scp);
            }
          }
        });
      }
    }   // end paint()
  }; // end return Extension object
} );
