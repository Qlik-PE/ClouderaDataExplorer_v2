// Translation table for property labels
define([
  "jquery"
],
  function ($) {

    var WebSocket = window.WebSocket || window.MozWebSocket;

    function Connection(config, appid) {
      this.config = config;
      if(appid) {
        this.config.appname = appid;
      }
    }

    Connection.prototype.open = function() {
      var self = this;
      self.seqid = 0;
      self.pending = {};
      self.handles = {};
      self.debug = self.config.debug;

      var prefix = self.config.prefix ? self.config.prefix : '/';

      if (prefix.slice(0, 1) !== '/') {
        prefix = '/' + prefix;
      }
      if (prefix.split('').pop() !== '/') {
        prefix = prefix + '/';
      }
      self.config.prefix = prefix;
    };

    Connection.prototype.connect = function() {
      var self = this;

      var deferred = $.Deferred();

      var isSecure = (self.config && self.config.isSecure) ? 'wss://' : 'ws://';
      var error = self.config ? self.config.error : null;

      var suffix = self.config.appname ? 'app/' + self.config.appname : 'app/%3Ftransient%3D';
      var identity = (self.config && self.config.identity) ? '/identity/' + self.config.identity : '';
      var ticket = self.config.ticket ? '?qlikTicket=' + self.config.ticket : '';

      var host = (self.config && self.config.host) ? self.config.host : 'localhost';
      var port;

      if (self.config && self.config.host === undefined) {
        port = ':4848';
      } else {
        port = (self.config && self.config.port) ? ':' + self.config.port : '';
      }

      // this.ws = new WebSocket(isSecure + host + port + prefix + suffix + identity + ticket, null, self.config);
      self.ws = new WebSocket(isSecure + host + port + self.config.prefix + suffix + identity + ticket);

      self.ws.addEventListener('open',
        function open() {
          deferred.resolve("connected");
      });

      self.ws.addEventListener('error', function err(ev) {
        var errTxt = 'ODISession WebSocket error: ';
        if (error) {
          error(ev);
        } else if (ev.message) {
          // console.log(ev.message);
          console.log(errTxt + ev.message);
        } else {
          console.log(errTxt + " " + JSON.stringify(ev));
        }
        self.ws = null;

        // loop over all pending messages and issue rejects on their deferreds
        var toDelete = [];
        for (var msgId in this.pending) {
          if (this.pending.hasOwnProperty(msgId)) {
            var pending = this.pending[msgId];
            if (pending.defer) {
              pending.defer.reject(ev);
            }
            toDelete.push(msgId);
          }
        }
        for (var i = 0; i < toDelete.length; i++) {
          delete this.pending[toDelete[i]];
        }
      });

      self.ws.addEventListener('close', function close() {
        var unexpected = self.ws != null;
        if (unexpected) {
          var errTxt = 'ODISession: Unexpected WebSocket connection close';
          if(error) {
            error(errTxt);
          } else {
            console.log(errTxt);
          }
        }
        self.ws = null;
      });

      self.ws.addEventListener('message', function message(ev) {
        var proxyNotifications = [
            "OnLicenseAccessDenied",
            "OnLicenseAccessDeniedPendingUserSync",
            "OnSessionClosed",
            "OnNoAppFound",
            "OnEngineWebsocketFailed",
            "OnNoEngineAvailable",
            "OnSessionTimedOut",
            "OnSessionClosed",
            "OnNoDataPrepServiceAvailable",
            "OnDataPrepServiceWebsocketFailed"
        ];

        var msg = JSON.parse(ev.data);
        if (this.debug) {
          console.log('Incoming', msg);
        }

        if(!msg.id) {
          var errObj = null;
          if ( msg.method === "OnSessionLoggedOut" ) {
            errObj = msg.method;
          } else if (msg.method === "OnEngineWebsocketFailed") {
            errObj = {
              method: msg.method,
              message: "ProxyError: " + msg.params.message
            };
          } else if ( proxyNotifications.indexOf(msg.method ) > -1 ) {
            errObj = {
              method: msg.method,
              message: "ProxyError: " + msg.params.message
            };
          } else if ((msg.method === "OnAuthenticationInformation" && msg.params.mustAuthenticate) || (msg.params && msg.params.severity)) {
            errObj = msg.params;
          }
          if(errObj) {
            this.ws.close();
            this.ws = null;
            if(error) {
              return error(JSON.stringify(errObj,null,2));
            } else {
              console.log(JSON.stringify(errObj,null,2));
            }
          }
          return;
        }

        var pending = this.pending[msg.id];
        delete this.pending[msg.id];

        if (pending) {
          pending.defer.resolve(msg);
        }
      }.bind(self));
      return deferred.promise();
    };

    Connection.prototype.rpc = function(request) {
      var self = this;
      if (!self.ws) {
        return self.connect().then(
          function (result) {  //eslint-disable-line no-unused-vars
            if (this.debug) {
              console.log("CONNECT SUCCESS");
            }
          },
          function (rejection) {  //eslint-disable-line no-unused-vars
            if (this.debug) {
              console.log("CONNECT ERROR");
            }
          }
        ).then(function () {
          return self.rpc(request);
        });
      }

      request.id = ++self.seqid;
      request.jsonrpc = '2.0';

      var deferred = $.Deferred();
      self.pending[request.id] = {
        id: request.id,
        defer: deferred
      };
      self.ws.send(JSON.stringify(request));
      return deferred.promise();
    };

    Connection.prototype.close = function() {
      if(this.ws) {
        var tmp = this.ws;
        this.ws = null;
        return tmp.close();
      }
      return null;
    };

    var OpenSession = function (scope, appid) {
      var options = scope.backendApi.model.session.options;
      var sessionConfig = {
        host: window.location.host,
        isSecure: window.location.protocol === "https:"
      };
      if (options && options.prefix) {
        sessionConfig.prefix = options.prefix;
      }
      // sessionConfig.debug = true;  // remove comment for debugging log
      var session = new Connection(sessionConfig, appid);
      session.open();
      return session;
    };

    return {
      open:   OpenSession
    };
  }
);

